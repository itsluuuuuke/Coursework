#ifdef READCHAR_R_H
#define READCHAR_R_H

char ReadCharacter(int fd, int position);

#endif
