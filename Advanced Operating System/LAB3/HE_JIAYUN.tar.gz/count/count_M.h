#ifdef COUNT_M_H
#define COUNT_M_H

int CountCharacters(int fd, char character);

#endif
