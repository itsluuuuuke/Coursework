#include"readchar_R.h"
#include"count_M.h"
#include<stdlib.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>

char ReadCharacter(int fd, int position);
int CountCharacters(int fd, char character);

int main(int argc, char **argv)
{
	printf("function type(R or M) filename character/position\n");
	//Check the number of the parameters
	if(argc != 4){
		printf("Incorrect Parameter! Please enter 3 parameters");
		exit(-1);
	}
	
	//Open the file indicate in the parameter
	int fd = open(argv[2],O_RDONLY);
	if(fd == -1){
		printf("Failed to open file!");
		exit(-1);
	}
	
	//Function type = readcharacter
	if(!strcmp(argv[1],"R")){
		printf("Character in position %d is: ",atoi(argv[3]));
		printf("%c\n",ReadCharacter(fd,atoi(argv[3])));
	}

	else if(!strcmp(argv[1],"M")){
		printf("Occurence of character %c is: ",argv[3][0]);
		printf("%d\n",CountCharacters(fd,argv[3][0]));
	}
	
	else{
		printf("Incorrect Function type! R or M\n");
		exit(-1);
	}
	return 0;
}
